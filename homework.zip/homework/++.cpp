#include <iostream>
using namespace std;

int main()
{
    int a=1,b=0;

    while (a<101){
        b+=a;
        a++;
    }
    cout<<b<<endl;
    return 0;
}