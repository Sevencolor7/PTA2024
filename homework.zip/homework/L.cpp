#include <iostream>
#include <iomanip>
using namespace std;
 int main(){
    double x,ans;
    cin>>x;
    cout<<x<<endl;
    if(x<5)ans=-x+2.5;
    else if(x>=10)ans=x/2-1.5;
    else ans=2-1.5*(x-3)*(x-3);
    printf("%.3lf",ans);

     return 0;
 }
 //#include <ionanip> fixed<<setprecision(3)