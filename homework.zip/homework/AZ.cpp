#include <iostream>
#include <string>
using namespace std;

int main() {
    string input;
    getline(cin,input);
    int ans=0;
    for(int i=0;i<input.length();i++){
        if (isdigit(input[i]))ans+=1;
    }
    cout<<ans<<endl;
    return 0;
}