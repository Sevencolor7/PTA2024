#include<iostream>
using namespace std;

int sol(int x){
    int k=0;
    while(x!=0){
        if (x%10==1)k++;
        x=x/10;

    }
    return k;
}
int main()
{
    int n,sum=0;
    cin>>n;
    for(int i=0;i<=n;i++){
        sum+=sol(i);
    }
    cout<<sum<<endl;
    return 0;
}