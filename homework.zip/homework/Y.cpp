#include <iostream>
using namespace std;
int main(){
    int sum=0,a,aa,n;
    cin>>a>>n;
    aa=a;
    for (int i=1;i<=n;i++){
        sum+=aa;
        aa=aa*10+a;

    }
    printf("%d",sum);
    return 0;
}