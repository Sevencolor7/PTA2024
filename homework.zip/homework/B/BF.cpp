#include <bits/stdc++.h>
using namespace std;
int n, m;
int dir[5][2] = {{0, 0}, {0, 1}, {0, -1}, {1, 0}, {-1, 0}};
int check(int x, int y) {
    // 判断是否需要平均
    return !(x == 0 || x == n - 1 || y == 0 || y == m - 1);
}
int main()
{
    cin >> n >> m;
    int a[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }
    int ans[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (check(i, j))
            
            {
                int sum = 0;
                for (int k = 0; k < 5; k++)
                {// 计算周围的和

                    sum += a[i + dir[k][0]][j + dir[k][1]];
                    
                }
                ans[i][j] = round(sum / 5.0);
            }
            else
            {
                ans[i][j] = a[i][j];
            }
        }
    }
    // 输出
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            printf("%d ", ans[i][j]);
        }
        printf("\n");
    }
}