#include<bits/stdc++.h>
using namespace std;
int sum[305];
int main(){
    int a,b,c;
    cin>>a>>b>>c;
    for(int i=1;i<=a;i++){
        for(int j=1;j<=b;j++){
            for(int k=1;k<=c;k++){
                sum[i+j+k]++;
            }
        }
    }
    int max=-1e9;
    vector<int> maxi;
    for (int i = 0;i<=300;i++)
    {
        if(sum[i]>max){
            max=sum[i];
            maxi.clear();
            maxi.push_back(i);
        }
        else if(sum[i]==max){
            maxi.push_back(i);
        }
    }
    for (int i = 0; i < maxi.size(); i++)
    {
        printf("%d ",maxi[i]);

    }
    
    return 0;
}