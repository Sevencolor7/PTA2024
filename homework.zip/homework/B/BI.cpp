#include <bits/stdc++.h>
using namespace std;
int n;
int main()
{
    // 2*n-1
    
    cin >> n;
    char a[2*n][2*n];
    char b[n];
    for (int i = 0; i < n; i++)
    {
        cin >> b[i];
    }
    for (int i = 0; i< n ; i++)
    {
        char x = b[i];
        for (int j = i; j < 2*n-i-1; j++)
        {
            a[i][j]=x;//顶部
            a[j][i]=x;//左侧
            a[2*n-i-2][j]=x;//底部  
            a[j][2*n-i-2]=x;//右侧

        }
    }
    // 输出
    for (int i = 0; i < 2*n - 1; i++)
    {
        for (int j = 0; j < 2*n - 1; j++)
        {
            cout << a[i][j];
        }
        cout << "\n";
    }


    return 0;
}