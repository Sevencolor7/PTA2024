#include<bits/stdc++.h>
using namespace std;
int main(){
    int N;
    cin>>N;
    int a[N+1];
    for(int i=1;i<=N;i++){
        cin>>a[i];
    }
    int ans=0,sum=1;
    for(int i=2;i<=N;i++){
        
        if (a[i]>a[i-1]){
            sum+=1;
            continue;
        }
        if (sum>ans){ans=sum;}
        sum=1;

    }
    if (sum>ans){ans=sum;}
    printf("%d",ans);

    return 0;
}