#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int num=1;
    vector<vector<int>> a(n,vector<int>(n,0));
    int top=0,right=n-1,bottom=n-1,left=0;
    while(top<=bottom&&left<=right){
        //左
        for (int i = left; i <= right; i++)
        {
            a[top][i]=num++;
        }
        top++;
        for (int i = top; i <=bottom; i++)
        {
            a[i][right]=num++;
        }
        right--;
        for (int i = right; i >= left; i--)
        {
            a[bottom][i]=num++;
        }
        bottom--;
        for (int i = bottom; i >= top; i--)
        {
            a[i][left]=num++;
        }
        left++;
        
        
    }
    int S=0,P=0;
    for (int i = 0; i < n; i++) {
        S += a[i][i];           // 主对角线
        P += a[i][n - i - 1];   // 副对角线
    }
    cout << S * P << endl;
    return 0;
}