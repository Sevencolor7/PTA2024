#include<bits/stdc++.h>
using namespace std;
int n;
int check(int x,int y){
    if(x>=0&&y>=0&&x<n&&y<n){
        return 1;
    }
    else{
        return 0;
    }
}
vector<vector<int>> generate(int n){
    vector<vector<int>> a(n,vector<int>(n,0));
    int num=1;
    for(int i=1;i<2*n;i++){
        if (i&1==1)
        {
            int x=i-1;
            int y=0;
            while(x!=-1){
                if(check(x,y)){
                    a[x][y]=num;
                    num++;
                }
                x--;
                y++;
            }
        }
        else{
            int x=0;
            int y=i-1;
            while(y!=-1){
                if(check(x,y)){
                        a[x][y]=num;
                        num++;
                    }
                    x++;
                    y--;
            }

        }

    }
    return a;


}
int main(){
    cin>>n;
    vector<vector<int>> arr=generate(n);
    //输出
    for (int  i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }
    
    return 0;
}