#include<bits/stdc++.h>
using namespace std;
int main(){
    long long n,m;
    cin>>n>>m;
    vector<long long> a(5,0);
    vector<long long> b(5,0);
    for(int i=1;i<=n;i++){
        a[i%5]++;
    }
    for(int i=1;i<=m;i++){
        b[i%5]++;
    }

    long long cnt=0;
    for(int i=0;i<5;i++){
        cnt+=a[i]*b[(5-i)%5];
    }
    cout<<cnt;
    return 0;
}