#include <bits/stdc++.h>
using namespace std;

int n, m;
char grid[105][105];
int dir[8][2] = {
    {-1, -1}, {-1, 0}, {-1, 1},
    {0, -1}, {0, 1},
    {1, -1}, {1, 0}, {1, 1}
};

int count(int x, int y) {
    int count = 0;
    for (int i = 0; i < 8; i++) {
        int nx = x + dir[i][0];
        int ny = y + dir[i][1];
        if (nx >= 0 && nx < n && ny >= 0 && ny < m && grid[nx][ny] == '*') {
            count++;
        }
    }
    return count;
}

int main() {
    cin >> n >> m;
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> grid[i][j];
        }
    }
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (grid[i][j] == '*') {
                cout << '*';
            } else {
                int mine = count(i, j);
                cout << mine;
            }
        }
        cout << endl;
    }

    return 0;
}
