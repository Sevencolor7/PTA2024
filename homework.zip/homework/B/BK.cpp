#include<bits/stdc++.h>
using namespace std;
vector<vector<int>> a(101,vector<int>(101,0));
int n;
int ch=1;
int x,y;

int check(int x,int y){
    if(x>=0&&y>=0&&x<n&&y<n&&a[x][y]==0){
        return 1;
    }
    else{
        return 0;
    }
}
void down(){
    while(check(x,y)){
        a[x][y]=ch;
        ch+=1;
        x+=1;
    }
    x-=1;
    y-=1;
}
void left(){
    while(check(x,y)){
        a[x][y]=ch;
        ch+=1;
        y-=1;
    }
    y+=1;
    x-=1;
}
void up(){
    while(check(x,y)){
        a[x][y]=ch;
        ch+=1;
        x-=1;
    }
    x+=1;
    y+=1;
}
void right(){
    while(check(x,y)){
        a[x][y]=ch++;

        y+=1;
    }
    y-=1;
    x+=1;
}

void round(int n){
    x=0;
    y=n-1;
    while(check(x,y)){
        down();
        left();
        up();
        right();
    }
}
int main(){
    cin>>n;
    round(n);
//输出  
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<"\n";
    
    }
    return 0;
}    