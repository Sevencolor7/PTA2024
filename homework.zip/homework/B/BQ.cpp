#include<bits/stdc++.h>
using namespace std;
int a[105];
int main(){
    int key=1;
    int n;
    cin>>n;
    for (int i = 1; i <= n; i++)
    {
        a[i]=i;
    }
    int num=1;
    
    for (int i = 1; i <= n; i++){
        if(num==key){
            key++;
            num=1;
            a[i]=0;
            continue;
        }
        if(a[i]!=0){
            num++;
        }
    }
    key=1;
    num=1;
    for (int i = n; i >=1; i--)
    {
        if(num==key&&a[i]!=0){
            key++;
            num=1;
            a[i]=0;
            continue;
        }
        if(a[i]!=0){
            num++;
        }
    }
    for (int  i = 1; i <= n; i++)
    {
        if(a[i]!=0){
            cout<<a[i]<<" ";
        }

    }
    

    return 0;
}
