#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    // 左边遍历
    vector<int> b(n);
    for (int i = 0; i < n; i++)
    {
        int sum = 0;
        for (int j = 0; j < i; j++)
        {

            if (a[j] < a[i])
            {
                sum++;
            }
        }
        b[i] = sum;
    }
    // out
    for (int i = 0; i < n; i++)
    {
        cout << b[i] << " ";
    }

    return 0;
}