#include<bits/stdc++.h>
using namespace std;
int main(){
    string a,b;
    cin>>a>>b;
    if(a==b){cout<<a;}
    else{cout<<1;}

    return 0;
}