#include <bits/stdc++.h>
using namespace std;

int main() {
    int tag1=1,tag2=1;
    int x[5][5];
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            cin >> x[i][j];
            }
        }
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            tag1=1,tag2=1;
            //枚举是否是行的最大值,第i行
            for(int k=0;k<5;k++){
                if(x[i][j]<x[i][k]){
                    tag1=0;
                }
            }
            //是否是列的最小值
            for(int k=0;k<5;k++){
                if(x[i][j]>x[k][j]){
                    tag2=0;
                }
            }
            if(tag1&&tag2){printf("%d %d %d",i+1,j+1,x[i][j]);return 0;}
                   
        }
    }
    if(tag1+tag2<2){
        cout << "not found" << endl;
    }
    return 0;
}
