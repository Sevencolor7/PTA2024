#include<bits/stdc++.h>
using namespace std;
int main(){
    unordered_map<string,string> a;
    string m;
    getline(cin,m);
    for(int i=0;i<10;i++){
        string s;
        cin>>s;
        a[s]=char(48+i);
    }
    string ans;
    for(int i=0;i<80;i+=10){
        string s=m.substr(i,10);
        ans+=a[s];
    }
    printf("%s",ans);

}