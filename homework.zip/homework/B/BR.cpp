#include <iostream>
#include <unordered_map>
#include <string>
using namespace std;

int main()
{
    // 初始化映射表，根据题目给出的替换规则
    unordered_map<char, char> replaceMap = {
        {'A', 'E'}, {'B', 'C'}, {'C', 'F'}, {'D', 'A'}, {'E', 'J'}, {'F', 'K'}, {'G', 'L'}, {'H', 'B'}, {'I', 'D'}, {'J', 'G'}, {'K', 'H'}, {'L', 'I'}, {'M', 'V'}, {'N', 'W'}, {'O', 'Z'}, {'P', 'Y'}, {'Q', 'M'}, {'R', 'N'}, {'S', 'O'}, {'T', 'P'}, {'U', 'Q'}, {'V', 'R'}, {'W', 'S'}, {'X', 'T'}, {'Y', 'U'}, {'Z', 'X'}, {'a', 'e'}, {'b', 'r'}, {'c', 'w'}, {'d', 'q'}, {'e', 't'}, {'f', 'y'}, {'g', 'g'}, {'h', 'h'}, {'i', 'b'}, {'j', 'n'}, {'k', 'u'}, {'l', 'i'}, {'m', 'o'}, {'n', 'p'}, {'o', 's'}, {'p', 'j'}, {'q', 'k'}, {'r', 'd'}, {'s', 'l'}, {'t', 'f'}, {'u', 'a'}, {'v', 'z'}, {'w', 'x'}, {'x', 'c'}, {'y', 'v'}, {'z', 'm'}};

    string input;
    getline(cin,input);
    for(char &ch:input){
        if(replaceMap.find(ch)!=replaceMap.end()){
            ch=replaceMap[ch];
        }
    }
    cout<<input<<"\n";
}
