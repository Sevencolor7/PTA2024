#include<bits/stdc++.h>
using namespace std;
int main(){
    int m,n;
    cin>>m>>n;
    queue<int> q;
    for (int  i = 0; i < m; i++)
    {
        q.push(i+1);//输出的是从1开始的数字
    }
    while (!q.empty()){
        for(int i = 0; i < n-1; i++){
            q.push(q.front());
            q.pop();
        }
        cout<<q.front()<<" ";
        q.pop();
    }
    
    return 0;
}