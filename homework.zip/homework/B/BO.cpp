#include <iostream>
#include <string>
using namespace std;

string get_min_number(string num)
{
    int len = num.size();
    for (int i = 0; i < len - 1; i++)
    {
        if (num[i] > num[i + 1])
        {
            return num.substr(0, i) + num.substr(i + 1);
        }
    }
    // 如果数字是递增的，删除最后一个字符
    return num.substr(0, len - 1);
}

int main()
{
    int n;
    string num;
    while (cin >> num)
    {

        cout << get_min_number(num) << endl;
    }
    return 0;
}