#include<iostream>
using namespace std;

int main()
{
    string a;
    cin>>a;
    cout<<"  "<<a<<endl;
    cout<<" "<<a+a+a<<endl;
    cout<<a+a+a+a+a<<endl;
    return 0;
}