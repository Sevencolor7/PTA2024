#include <iostream>
using namespace std;

int main() {
    int a,b;
    cin>>a;
    b=a%7;
    if (b==0)
    {
        b=7;
    }
    cout<<b<<endl;
    return 0;
}