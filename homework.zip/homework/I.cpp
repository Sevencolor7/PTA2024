#include <iostream>
using namespace std;

int main(){
    int a,b;
    cin>>a;
    if ((a>9)&&(a<100)){
        cout<<1<<endl;

    }else{cout<<0<<endl;}
    return 0;
}