#include <iostream>
using namespace std;

int main() {
    int a,b;
    cin>>a>>b;
    double c;
    c=1.0*a/b;
    cout.precision(9);
    cout<<fixed<<c<<endl;
    return 0;
}
    