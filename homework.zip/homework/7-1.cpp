#include<iostream>
using namespace std;
int main(){
    int f=100,c;
    c=5*(f-32)/9;
    cout<<"fahr = 100, celsius = "<<c<<endl;
    return 0;
}