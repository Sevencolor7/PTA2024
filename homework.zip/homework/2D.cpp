#include<iostream>
using namespace std;
int main(){
    int x,y;
    double ans;
    cin>>x>>y;
    cout.precision(2);
    ans=1.0*(87*x+85*y)/(x+y);
    cout<<fixed<<ans<<endl;
    return 0;
}