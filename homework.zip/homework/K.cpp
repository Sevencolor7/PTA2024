#include <iostream>
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

int main()
{
    int a,b,d;
    string c;
    cin>>a>>b>>c;
    if(c=="+"){
        d=a+b;
    }else if(c=="-"){
        d=a-b;
    }else if(c=="*"){
        d=a*b;
    }else if(c=="/"){
        if(b==0){
            cout<<"Divided by zero!"<<endl;
            return 0;//
        }else{
            d=a/b;
    }
    }else{
        cout<<"invalid operator!"<<endl;
        return 0;
    }
        cout<<d<<endl;
    return 0;
}

#include <iostream>
using namespace std;

int main() {
    int a, b, d;
    string c;
    cin >> a >> b >> c;

    if (c == "+") {
        d = a + b;
    } else if (c == "-") {
        d = a - b;
    } else if (c == "*") {
        d = a * b;
    } else if (c == "/") {
        if (b == 0) {
            cout << "Divided by zero!" << endl;
            return 0; // 直接结束程序
        } else {
            d = a / b;
        }
    } else {
        cout << "Invalid operator!" << endl;
        return 0; // 直接结束程序
    }

    cout << d << endl; // 输出结果
    return 0;
}

