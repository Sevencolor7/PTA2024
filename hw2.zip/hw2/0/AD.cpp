#include<bits/stdc++.h>
using namespace std;
int one(int x){
    int num=0;
    while(x!=0){
        if(x%10==2){
            num+=1;
        }
        x=x/10;
    }
    return num;
}
int main(){
    int L,R,sum=0;
    cin>>L>>R;
    for(int i=L;i<=R;i++){
        sum+=one(i);
    }
    cout<<sum;
    
 
    return 0;
}