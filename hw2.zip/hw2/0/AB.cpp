#include<bits/stdc++.h>
using namespace std;
int main(){
    int f1=1,f2=1,n;
    cin>>n;
    int next,sum=2,i=3;
    while(i<=n){
        next=f1+f2;
        f1=f2;
        f2=next;
        sum+=next;
        i++;
    }
    cout<<sum<<endl;
    return 0;
}