#include<bits/stdc++.h>
using namespace std;
int sum(int n){
    int sum=0;
    for(int i=1;i<n;i++){
        if (n%i==0)sum+=i;
    }
    return sum;

}
int main(){
    int m,n;
    cin>>m>>n;
    if (m>n)swap(m,n);
    int i=m;
    for(i;i<n;i++)
        if(sum(i)==i)cout<<i<<"  ";
    return 0;
}