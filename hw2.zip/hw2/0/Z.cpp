#include<bits/stdc++.h>
using namespace std;
int one(int x){
    int num=0;
    while(x!=0){
        if(x%10==1){
            num+=1;
        }
        x=x/10;
    }
    return num;
}
int main(){
    int n,sum=0;
    cin>>n;
    for(int i=1;i<=n;i++){
        sum+=one(i);
    }
    cout<<sum;
    
 
    return 0;
}