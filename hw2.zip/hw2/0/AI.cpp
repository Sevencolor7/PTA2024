#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    for (int x=1;x<sqrt(n);x++){
        int y2=n-pow(x,2);
        int y=sqrt(y2);
        if(pow(y,2)==y2&&y>0){
            cout<<x<<" "<<y<<endl;
        }
    }
 
    return 0;
}