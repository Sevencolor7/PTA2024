#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    for(int i=1;i<=(n+1)/2;i++){
        for(int j=i+1;j<=(n+1)/2;j++){
            cout<<" ";
        }
        for(int j=1;j<=2*i-1;j++){
            cout<<'*';
        }
        cout<<endl;
        
    }
    for(int i=1;i<=(n-1)/2;i++){
        for(int j=2;j<=(n+1)/2;j++){
            cout<<" ";
        }
        cout<<'*'<<endl;
    }
 
    return 0;
}