#include<bits/stdc++.h>
using namespace std;
int stage(int x){
    if (x==1)return 1;
    return x*stage(x-1);
}
int main(){
    int i=1;
    double sum=1;
    int n;
    cin>>n;

    while(i<=n){
        sum+=1.0*1/stage(i);
        i++;
    }
    cout<<fixed<<setprecision(10)<<sum;
    return 0;
}