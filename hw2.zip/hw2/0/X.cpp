#include<bits/stdc++.h>
using namespace std;

int main(){
    double x,sum=1,t=1.0;
    int n;
    cin>>x>>n;
    for(int i=1;i<=n;i++){
        t=x*t;
        sum+=t;
    }
    cout<<fixed<<setprecision(2)<<sum;
    
    
    return 0;
}