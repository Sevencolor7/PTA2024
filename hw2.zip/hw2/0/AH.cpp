#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,f;
    cin>>n>>f;
    for(int i=0;i<=n;i++){
        int r=n-i;
        int sum=4*r+2*i;
        if (sum==f){
            printf("鸡的个数为%d 兔子的个数为%d",i,r);
            break;
        }
    }
 
    return 0;
}