#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,sum=0;
    cin>>n;
    int a[n][n];
    for (int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>>a[i][j];
            if (a[i][j]==0){
                sum+=1;
            }
        }
    }
    cout<<sum;
    
    

    
    return 0;
}