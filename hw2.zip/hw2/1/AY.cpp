#include<bits/stdc++.h>
using namespace std;
int main(){
    string a;
    cin>>a;
    int  num[27]={0};
    for (int i=0;i<a.size();i++){
        num[int(a[i]-97)]+=1;
    }
    for (int i=0;i<26;i++){
        if (num[i]==1){
            cout<<char(i+97);
            return 0;
        }
    }
    cout<<"no"<<endl;
    return 0;
}
