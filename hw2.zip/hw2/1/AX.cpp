#include<bits/stdc++.h>
using namespace std;
int main(){
    string a,in="(max)";
    cin>>a;
    vector<int> num={};
    char max='a';
    for (int i=0;i<a.size();i++){
        if (a[i]>max){
            max=a[i];
        }

    }
    for (int i=0;i<a.size();i++){
        if (a[i]==max){
            num.push_back(i);
        }
    }
    for(int i=num.size()-1;i>=0;i--){
        a.insert(num[i]+1,in);

    }
    cout<<a<<endl;

    

 
    return 0;
}