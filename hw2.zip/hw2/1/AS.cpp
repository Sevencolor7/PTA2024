#include<bits/stdc++.h>
using namespace std;
set<int> a;
int len,n;
int main(){
    cin>>len>>n;
    for(int i=1;i<=n;i++){
        int s,e;
        cin>>s>>e;
        for(int j=s;j<=e;j++){
            a.insert(j);
        }
    }
    cout<<len-a.size()+1<<endl;
    return 0;
}
