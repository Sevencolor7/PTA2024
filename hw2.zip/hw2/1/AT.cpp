#include <iostream>
#include <vector>
using namespace std;

int main() {
    int N, x, y;
    cin >> N >> x >> y;

    // 同一行的格子
    for (int j = 1; j <= N; ++j) {
        cout << "(" << x << "," << j << ") ";
    }
    cout << endl;

    // 同一列的格子
    for (int i = 1; i <= N; ++i) {
        cout << "(" << i << "," << y << ") ";
    }
    cout << endl;

    // 左上到右下的对角线
    for (int i = 1; i <= N; ++i) {
        int j = x + (i - y);
        if (j >= 1 && j <= N) {
            cout << "(" << j << "," << i << ") ";
        }
    }
    cout << endl;

    // 左下到右上的对角线
    for (int i = N; i >=1; i--) {
        int j = y + (x - i);
        if (j >= 1 && j <= N) {
            cout << "(" << i << "," << j << ") ";
        }
    }
    cout << endl;

    return 0;
}
