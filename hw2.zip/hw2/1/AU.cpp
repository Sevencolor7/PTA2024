#include<bits/stdc++.h>
using namespace std;
int main(){
    int sum=0,m,n;
    cin>>m>>n;
    int a[n+1][n+1];
    for (int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>a[i][j];
            if(i==0||i==n-1||j==0||j==n-1){
                sum+=a[i][j];
            }
        }
    }
    cout<<sum<<endl;
    
    return 0;
}