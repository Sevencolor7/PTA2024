#include<bits/stdc++.h>
using namespace std;
int main(){
    int a[11];
    for(int i=1;i<=10;i++){
        cin>>a[i];
    }
    int h,sum=0;
    cin>>h;

    for(int i=1;i<=10;i++){
        if(a[i]<=h+30){
            sum+=1;

        }
    }
    cout<<sum;
    return 0;
}