#include<bits/stdc++.h>
using namespace std;

int main(){
    int n,m,last=1;
    cin>>n>>m;
    vector<int> light(2*n,0);
    for(int i=2;i<=m;i++){
        for (int j=i;j<=n;j+=i){
            light[j]=1-light[j];
        }
    }
    for (int i=1;i<=n;i++){
        if(light [i]==0){
            last=i;
            
        }
    }
    for (int i=1;i<=n;i++){
        if(light [i]==0){
            printf("%d",i);
            if (i!=last){cout<<",";}
        }
    }
    return 0;
}