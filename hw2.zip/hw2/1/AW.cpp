#include<bits/stdc++.h>
using namespace std;
int add(string x){
    int sum=0;
    for(char i:x){
        sum+=i-64;
    }
    return sum;
}
int main(){
    string a;
    cin>>a;
    cout<<add(a);
    return 0;
}