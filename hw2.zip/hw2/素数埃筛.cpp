#include<bits/stdc++.h>
using namespace std;
int a[1001];
bool su(int num){
    if(num<=1) return false;
    for(int i=2;i*i<=num;i++){
        if(num%i==0)return false;
    }
    return true;
}
void ask(int n){
    
    for(int i=0;i<n+1;i++){
        a[i]=0;
    }
    for(int i=2;i<n;i++){
        if (a[i]==0&&su(i)){
            for (int j=i*i;j<=n;j+=i){
                a[j]=1;
            }

        }
    }
}
int main(){
    int n;
    ask(1000);
    while(cin>>n){
        int ans;
        for(int i=2;i*i<=n;i++)if(a[i]==0)ans+=1;
        cout<<ans<<endl;
    }
    return 0;
}