#include <iostream>
using namespace std;

int main() {
    int N;
    cin >> N;  // 输入一个正整数 N

    // 如果输入为1，直接输出"End"
    if (N == 1) {
        cout << "End" << endl;
        return 0;
    }

    // 输出过程
    while (N != 1) {
        if (N % 2 == 0) {  // 如果是偶数
            cout << N << "/2=" << N / 2 << endl;
            N /= 2;  // 除以2
        } else {  // 如果是奇数
            cout << N << "*3+1=" << 3 * N + 1 << endl;
            N = 3 * N + 1;  // 乘以3加1
        }
    }

    cout << "End" << endl;  // 输出结束标志
    return 0;
}
