#include<bits/stdc++.h>
using namespace std;
bool su(int num){
    if(num<=1) return false;
    for(int i=2;i*i<=num;i++){
        if(num%i==0)return false;
    }
    return true;
}
int main(){
    int m,n,sum=0,num=0;
    cin>>m>>n;
    if(m>n)swap(m,n);
    for(int i=m;i<n;i++){
        if (su(i)){
            num+=1;
            sum+=i;
        }
    }
    printf("%d  %d",num,sum);
    return 0;
}
