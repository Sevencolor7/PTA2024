#include<iostream>
using namespace std;
double lv(int n,int c){
    return 1.0*c/n;
}
int main(){
    int n;
    cin>>n;
    int x1,x2;
    cin>>x1>>x2;
    double x=lv(x1,x2);
    for (int i = 1; i <n; i++)
    {
        int x3,x4;
        cin>>x3>>x4;
        double y=lv(x3,x4);
        if(y-x>0.05){cout<<"better"<<endl;}
        else if(x-y>0.05){cout<<"worse"<<endl;}
        else{ cout <<"same"<<endl;}
    }
    
    return 0;
}