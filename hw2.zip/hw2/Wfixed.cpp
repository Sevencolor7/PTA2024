#include<bits/stdc++.h>
using namespace std;
const int maxn=1000;
bool isP[maxn+1];
int Pout[maxn+1];
void sieve(){
    fill(isP,isP+maxn+1,true);
    isP[0]=isP[1]=false;
    for(int i=2;i*i<=maxn;i++){
        if(isP[i]){
            for(int j=i*i;j<=maxn;j+=i){
                isP[j]=false;
            }
        }
    }
    Pout[0]=Pout[1]=0;
    for(int i=2;i<=maxn;i++){
        Pout[i]=Pout[i-1]+(isP[i]?1:0);
    }

}
int main(){
    sieve();
    int N;
    while(cin>>N){
        cout<<Pout[N]<<endl;
    }
    return 0;
}