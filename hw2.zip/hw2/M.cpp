#include<iostream>
using namespace std;
int main(){
    int ans=0,n;
    cin>>n;
    for (int i=0;i<n;i++){
        int x=0;
        cin>>x;
        if (x%2==0)ans+=x;

    }
    cout<<ans<<"\n";
    return 0;
}
