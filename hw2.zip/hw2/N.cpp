#include<iostream>
using namespace std;
int main(){
    int i=10;
    for(i;i<1000;i++){
        if (i%2==0 &&i%3==0&&i%7==0){
            cout<<i<<endl;
        }
    }
    return 0;
}