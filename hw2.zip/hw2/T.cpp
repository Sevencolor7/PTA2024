#include<iostream>
using namespace std;
int main(){
    double sum=0;
    int i=1,k;
    cin>>k;
    while (sum<=k){
        sum=sum+1.0*1/i;
        i++;

    }
    cout<<i-1;
    
    return 0;
}