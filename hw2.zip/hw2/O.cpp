#include<iostream>
using namespace std;
int main(){
    int i=0,x,n,max=0,min=999;
    cin>>n;
    while(i<n)
    {
        cin>>x;
        if(x<min)min=x;
        if(x>max)max=x;
        i++;   
    }
    cout<<max-min<<endl;
    
    return 0;
}